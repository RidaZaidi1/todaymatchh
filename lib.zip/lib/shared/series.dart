// ignore_for_file: prefer_const_declarations

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:today/screens/homee4.dart';

import '../modecontroller.dart';
import 'package:http/http.dart' as http;

class Series extends StatefulWidget {
  const Series({Key? key}) : super(key: key);

  @override
  State<Series> createState() => _SeriesState();
}

final controller = Get.put(DarkModeController());

class _SeriesState extends State<Series> {
  void initState() {
    super.initState();
    getSeries();
  }

  var SeriesList = [];

  getSeries() async {
    final String apiUrl =
        'https://rest.entitysport.com/v2/seasons/2021/competitions?token=ec471071441bb2ac538a0ff901abd249';
    final response = await http.get(Uri.parse(apiUrl));
    var data = json.decode(response.body);

    for (var i = 0; i < data["response"]["items"].length; i++) {
      SeriesList.add(data["response"]["items"][i]);
    }
    final String apiUrl1 =
        'https://rest.entitysport.com/v2/seasons/2022/competitions?token=ec471071441bb2ac538a0ff901abd249';
    final response1 = await http.get(Uri.parse(apiUrl));
    var data1 = json.decode(response.body);

    for (var i = 0; i < data["response"]["items"].length; i++) {
      SeriesList.add(data["response"]["items"][i]);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: 
          
         SeriesList.length== 0 ?Center(child: CircularProgressIndicator(
          strokeWidth: 5,
         )): Column(
            children: [
            ListView.builder(
              shrinkWrap: true,
              physics: BouncingScrollPhysics(),
              itemBuilder: ((context, index) {
                // print(matchlist[index]);

                return Card(
                  elevation: 100,
                  color: Colors.transparent,
                  child: Column(mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 60.0),
                        child: GestureDetector(
                            onTap: () {
                              // Get.to(Homee5());
                            },
                            child: Text(
                              "${SeriesList[index]["title"]} 2023",
                              style: TextStyle(
                                  color: controller.mode == 'light'
                                      ? Color(0xff020e28)
                                      : Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500),
                            )),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(SeriesList[index]["datestart"] +"  to  "+SeriesList[index]["dateend"],
                              style: TextStyle(
                                  color: controller.mode == 'light'
                                      ? Color(0xff1A3A90)
                                      : Color(0xff9db5ef),
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500)),
                          Padding(
                            padding:
                                const EdgeInsets.only(right: 25.0, bottom: 25),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: controller.mode == 'light'
                                  ? Color(0xff020e28)
                                  : Color(0xff9db5ef),
                              size: 20,
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                );
              }),
              scrollDirection: Axis.vertical,
              itemCount: SeriesList.length,
            )
          ]),
        ),
      ),
    );
  }
}
