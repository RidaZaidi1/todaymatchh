// ignore_for_file: use_key_in_widget_constructors, prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:today/screens/Squads/mainsquad.dart';
import 'package:get/get.dart';
import '../modecontroller.dart';
class Infoo extends StatefulWidget {
  // const Infoo({ Key? key }) : super(key: key);
  var data;
  Infoo(this.data);

  @override
  State<Infoo> createState() => _InfooState();
}
final controller = Get.put(DarkModeController());
class _InfooState extends State<Infoo> {

void initState(){
  super.initState();
  print(widget.data[0]["competition"]["match_format"]);
}

  @override
  Widget build(BuildContext context) {
   return Scaffold(
    backgroundColor: Colors.transparent,
body: SingleChildScrollView(
  child:   Column(
  
    children: [
      SizedBox(height: 30,),
  Padding(
    padding: const EdgeInsets.all(14.0),
    child: Container(
height: 430,
width: 380,
decoration: BoxDecoration(
      // ignore: prefer_const_literals_to_create_immutables
      boxShadow: <BoxShadow>[
                        BoxShadow(
                            color: Colors.black54,
                            blurRadius: 5.0,
                            offset: Offset(0.0, 0.25)
                        )
                      ],
  color: controller.mode == 'light'?Colors.white  :Color(0xff353e52),borderRadius: BorderRadius.circular(30)),

child:Column(
    children: [
      SizedBox(height: 55,),
Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Padding(
padding: const EdgeInsets.only(left:30.0),
child: Text('Match',style: TextStyle(color: controller.mode == 'light'? Color(0xff1A3A90) :Color(0xff9db5ef),fontSize: 13,fontWeight: FontWeight.w800),),
),
Padding(
padding: const EdgeInsets.only(right:90.0,),
child: Text(widget.data[0]["competition"]["match_format"],style: TextStyle(color:controller.mode == 'light'? Color(0xff020e28) : Colors.white,fontSize: 13,fontWeight: FontWeight.w800),),
),],),
SizedBox(height: 30,),
Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Padding(
padding: const EdgeInsets.only(left:30.0),
child: Text('Competition',style: TextStyle(color: controller.mode == 'light'? Color(0xff1A3A90) :Color(0xff9db5ef),fontSize: 13,fontWeight: FontWeight.w800),),
),
Padding(
padding: const EdgeInsets.only(right:70.0,),
child: Text(widget.data[0]["short_title"],style: TextStyle(color:controller.mode == 'light'? Color(0xff020e28) : Colors.white,fontSize: 13,fontWeight: FontWeight.w800),),
),],),
SizedBox(height: 30,),
Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Padding(
padding: const EdgeInsets.only(left:30.0),
child: Text('Date Time',style: TextStyle(color: controller.mode == 'light'? Color(0xff1A3A90) :Color(0xff9db5ef),fontSize: 13,fontWeight: FontWeight.w800),),
),
Padding(
padding: const EdgeInsets.only(right:67.0,),
child: Text(widget.data[0]["competition"]["datestart"],style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Colors.white,fontSize: 13,fontWeight: FontWeight.w800),),
),],),
SizedBox(height: 30,),
Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Padding(
padding: const EdgeInsets.only(left:30.0),
child: Text('Vanue',style: TextStyle(color:controller.mode == 'light'? Color(0xff1A3A90) : Color(0xff9db5ef),fontSize: 13,fontWeight: FontWeight.w800),),
),
Padding(
padding: const EdgeInsets.only(right:76.0,),
  
child: widget.data[0]["venue"]["name"].toString().length>24? Text(widget.data[0]["venue"]["name"].toString().substring(0,20),
style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Colors.white,fontSize: 13,fontWeight: FontWeight.w800),

):Text(widget.data[0]["venue"]["name"],style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Colors.white,fontSize: 13,fontWeight: FontWeight.w800),),
),],),
SizedBox(height: 30,),
Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Padding(
padding: const EdgeInsets.only(left:30.0),
child: Text('Vanue location',style: TextStyle(color: controller.mode == 'light'? Color(0xff1A3A90) :Color(0xff9db5ef),fontSize: 13,fontWeight: FontWeight.w800),),
),
Padding(
padding: const EdgeInsets.only(right:76.0,),
child:

 Text(widget.data[0]["venue"]["location"],style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Colors.white,fontSize: 13,fontWeight: FontWeight.w800),),
),],),
SizedBox(height: 30,),
Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Padding(
padding: const EdgeInsets.only(left:30.0),
child: Text("Umires",style: TextStyle(color: controller.mode == 'light'? Color(0xff1A3A90) :Color(0xff9db5ef),fontSize: 13,fontWeight: FontWeight.w800),),
),
Container(
  child:   Padding(
  
  padding: const EdgeInsets.only(right:0.0,),
  
  child: Text(widget.data[0]["umpires"].toString().substring(0,60),maxLines: 2,style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Colors.white,fontSize: 8,fontWeight: FontWeight.w800),),
  
  ),
),],),
SizedBox(height: 30,),
Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Padding(
padding: const EdgeInsets.only(left:30.0),
child: Text('Referee',style: TextStyle(color: controller.mode == 'light'? Color(0xff1A3A90) :Color(0xff9db5ef),fontSize: 13,fontWeight: FontWeight.w800),),
),
Padding(
padding: const EdgeInsets.only(right:70.0,),
child: Text(widget.data[0]["referee"],style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Colors.white,fontSize: 13,fontWeight: FontWeight.w800),),
),],),
SizedBox(height: 30,),
Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
Padding(
padding: const EdgeInsets.only(left:30.0),
child: Text('Toss',style: TextStyle(color:controller.mode == 'light'? Color(0xff1A3A90) : Color(0xff9db5ef),fontSize: 13,fontWeight: FontWeight.w800),),
),
Padding(
padding: const EdgeInsets.only(right:70.0,),
child: Text(widget.data[0]["toss"]["text"],style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Colors.white,fontSize: 13,fontWeight: FontWeight.w800),),
),],),
],),),
  ),
Transform.translate(offset:Offset(0, -470.0),
child:   Container(
height: 47,
width: 250,
decoration:BoxDecoration(color: Color.fromARGB(255, 238, 20, 20),borderRadius: BorderRadius.circular(10),),
child: Center(child:Text("Scheduled "+widget.data[0]["competition"]["datestart"],style: TextStyle(color: Colors.white,fontSize: 14,fontWeight: FontWeight.w800),)),
),),  
  
 Padding(
   padding: const EdgeInsets.only(right:250),
   child: Text('Playing 11',style: TextStyle(color: controller.mode == 'light'? Color(0xff1A3A90) :Color(0xff9db5ef),fontSize: 16,fontWeight: FontWeight.w600),),
 ),
  
SizedBox(height: 20,),
Padding(
  padding: const EdgeInsets.all(14.0),
  child:   Container(
  
  height: 150,
  
  width: 380,
  
  decoration: BoxDecoration(
     boxShadow: <BoxShadow>[
                        BoxShadow(
                            color: Colors.black54,
                            blurRadius: 5.0,
                            offset: Offset(0.0, 0.25)
                        )
                      ],
    
    
    
    
    color: controller.mode == 'light'?Colors.white  :Color(0xff353e52),borderRadius: BorderRadius.circular(30)),
  
  
  
  child: Column(
  
    children: [
  
  SizedBox(height:15 ,),
  
  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
  
  children: [
  
  Padding(
  
    padding: const EdgeInsets.only(left:10.0),
  
    child:   Image.asset('assets/ireland.png',height: 30,),
  
  ),
  
  Padding(
  
    padding: const EdgeInsets.only(right:90),
  
    child:   Text('Denmark',style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Color.fromARGB(255, 249, 249, 251),fontSize: 15,fontWeight: FontWeight.w600)),
  
  ),
  
  Padding(
  
    padding: const EdgeInsets.only(left:40.0),
  
    child:   Icon(Icons.arrow_forward_ios,color: controller.mode == 'light'? Color(0xff020e28) :Color(0xff9db5ef),size: 20,),
  
  )
  
  ],),
  
  
  
  Padding(
  
    padding: const EdgeInsets.only(left:25,right:25,top:20),
  
    child:   Divider(color: controller.mode == 'light'? Colors.grey :Colors.white,thickness: 1,),
  
  ),
  
    
  
  SizedBox(height:15 ,),
  
  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
  
  children: [
  
  Padding(
  
    padding: const EdgeInsets.only(left:10.0),
  
    child:   Image.asset('assets/ban.png',height: 30,),
  
  ),
  
  Padding(
  
    padding: const EdgeInsets.only(right:90),
  
    child:   Text('Norway',style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Color.fromARGB(255, 249, 249, 251),fontSize: 15,fontWeight: FontWeight.w600)),
  
  ),
  
  Padding(
  
    padding: const EdgeInsets.only(left:40.0),
  
    child:   Icon(Icons.arrow_forward_ios,color: controller.mode == 'light'? Color(0xff020e28) :Color(0xff9db5ef),size: 30,),
  
  )
  
  ],),],),),
),  


Padding(
   padding: const EdgeInsets.only(right:250,top: 30),
   child: Text('Squads',style: TextStyle(color: controller.mode == 'light'? Color(0xff1A3A90) :Color(0xff9db5ef),fontSize: 16,fontWeight: FontWeight.w600),),
 ),
  
SizedBox(height: 15,),
Padding(
  padding: const EdgeInsets.all(14.0),
  child:   Container(
  
  height: 150,
  
  width: 380,
  
  decoration: BoxDecoration(
     boxShadow: <BoxShadow>[
                        BoxShadow(
                            color: Colors.black54,
                            blurRadius: 5.0,
                            offset: Offset(0.0, 0.25)
                        )
                      ],
    
    
    
    color: controller.mode == 'light'?Colors.white  :Color(0xff353e52),borderRadius: BorderRadius.circular(30)),
  
  child: Column(
  
    children: [
  
  SizedBox(height:20 ,),
  
  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
  
  children: [
  
  Padding(
  
    padding: const EdgeInsets.only(left:10.0),
  
    child:   Image.asset('assets/ireland.png',height: 30,),
  
  ),
  
  Padding(
  
    padding: const EdgeInsets.only(right:90),
  
    child:   GestureDetector(
      onTap: (){
           Get.to( Squadmain());
      },
      child: Text('Denmark',style: TextStyle(color: controller.mode == 'light'? Color(0xff020e28) :Color.fromARGB(255, 249, 249, 251),fontSize: 15,fontWeight: FontWeight.w600))),
  
  ),
  
  Padding(
  
    padding: const EdgeInsets.only(left:40.0),
  
    child:   Icon(Icons.arrow_forward_ios,color: controller.mode == 'light'? Color(0xff020e28) :Color(0xff9db5ef),size: 20,),
  
  )
  
  ],),
  
  
  
  Padding(
  
    padding: const EdgeInsets.only(left:25,right:25,top:20),
  
    child:   Divider(color:controller.mode == 'light'? Colors.grey : Colors.white,thickness: 1,),
  
  ),
  
    
  
  SizedBox(height:15 ,),
  
  Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
  
  children: [
  
  Padding(
  
    padding: const EdgeInsets.only(left:10.0),
  
    child:   Image.asset('assets/ban.png',height: 30,),
  
  ),
  
  Padding(
  
    padding: const EdgeInsets.only(right:90),
  
    child:   Text('Norway',style: TextStyle(color:controller.mode == 'light'? Color(0xff020e28) : Color.fromARGB(255, 249, 249, 251),fontSize: 15,fontWeight: FontWeight.w600)),
  
  ),
  
  Padding(
  
    padding: const EdgeInsets.only(left:40.0),
  
    child:   Icon(Icons.arrow_forward_ios,color: controller.mode == 'light'? Color(0xff020e28) :Color(0xff9db5ef),size: 20,),
  
  )
  
  ],),
  
  ]),
  
  ),
),
      
  
    ],
  
  ),
),
   );
  }
}